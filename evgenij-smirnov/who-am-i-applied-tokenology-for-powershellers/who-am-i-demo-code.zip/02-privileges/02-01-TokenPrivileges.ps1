﻿<#
    Who am I? Applied Tokenology for PowerShellers

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Token privileges demonstration
#>
#region native code
$nativeCode = @'
using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Text;
[StructLayout(LayoutKind.Sequential)]
public struct LUID
{
    public uint LowPart { get; set; }
    public uint HighPart { get; set; }
}

[StructLayout(LayoutKind.Sequential)]
public struct LUID_AND_ATTRIBUTES
{
    public LUID Luid { get; set; }
    public UInt32 Attributes { get; set; }
}

[StructLayout(LayoutKind.Sequential)]
public struct PrivilegeList
{
    public int PrivilegeCount;
    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 40)]
    public LUID_AND_ATTRIBUTES[] PrivilegeArray;
}

public class TokenPrivilege
{
    public string Name { get; set; }
    public uint Status { get; set;  }
    public TokenPrivilege(string n, uint a)
    {
        Name = n;
        Status = a;
    }
}

public class WinNative
{
    public static int ticPrivileges = 3;

    [DllImport("Kernel32.dll", ExactSpelling = true)]
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    public static extern IntPtr GetCurrentProcess();

    [DllImport("Advapi32.dll", ExactSpelling = true)]
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    public static extern bool OpenProcessToken(IntPtr ProcessHandle, uint DesiredAccess, out SafeAccessTokenHandle TokenHandle);

    [DllImport("Advapi32.dll", ExactSpelling = true)]
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    public static extern bool GetTokenInformation(SafeAccessTokenHandle TokenHandle, int TokenInformationClass, IntPtr TokenInformation, UInt32 TokenInformationLength, out UInt32 ReturnLength);

    [DllImport("advapi32.dll", SetLastError = true)]
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    internal static extern bool LookupPrivilegeName(string host, ref LUID lpLuid, StringBuilder lpName, ref int cchName);

    public static List<TokenPrivilege> GetPrivileges()
    {
        List<TokenPrivilege> result = new List<TokenPrivilege>();
        IntPtr pHandle = GetCurrentProcess();
        SafeAccessTokenHandle tHandle;
        bool res = OpenProcessToken(pHandle, (uint)System.Security.Principal.TokenAccessLevels.Query, out tHandle);
        if (res)
        {
            UInt32 privilegesSize;
            res = GetTokenInformation(tHandle, ticPrivileges, IntPtr.Zero, 0, out privilegesSize);
            IntPtr privilegesBuffer = IntPtr.Zero;
            privilegesBuffer = Marshal.AllocHGlobal((int)privilegesSize);
            res = GetTokenInformation(tHandle, ticPrivileges, privilegesBuffer, privilegesSize, out privilegesSize);
            PrivilegeList pList = (PrivilegeList)Marshal.PtrToStructure(privilegesBuffer, typeof(PrivilegeList));
            StringBuilder pName = new StringBuilder();
            int cchName;
            LUID privLuid = new LUID();
            for (int i = 0; i < pList.PrivilegeCount; i++)
            {
                privLuid = pList.PrivilegeArray[i].Luid;
                cchName = 0;
                LookupPrivilegeName(null, ref privLuid, pName, ref cchName);
                pName.EnsureCapacity(cchName);
                res = LookupPrivilegeName(null, ref privLuid, pName, ref cchName);
                result.Add(new TokenPrivilege(pName.ToString(), pList.PrivilegeArray[i].Attributes));
            }
            Marshal.FreeHGlobal(privilegesBuffer);
        }
        return result;
    }
}
'@
Add-Type -TypeDefinition $nativeCode
#endregion
[WinNative]::GetPrivileges()