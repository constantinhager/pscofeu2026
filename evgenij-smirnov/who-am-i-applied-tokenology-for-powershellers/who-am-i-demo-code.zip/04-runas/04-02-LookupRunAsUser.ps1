﻿<#
    Who am I? Applied Tokenology for PowerShellers

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Look up runas /netonly user from event logs
#>
#region native code
$nativeCode = @'
using Microsoft.Win32.SafeHandles;
using System;
using System.Runtime.InteropServices;
public struct LogonSessionData
{
    public LUID LoginId;
    public UInt32 SessionId;
    public string AuthenticationPackage;
    public string UserName;
    public string LoginDomain;
    public string LogonServer;
    public string DnsDomainName;
    public string Upn;
    public string SID;
    public UInt32 LogonType;
    public UInt32 UserFlags;
}

[StructLayout(LayoutKind.Sequential)]
public struct LUID
{
    public uint LowPart { get; set; }
    public uint HighPart { get; set; }
}

public enum TOKEN_TYPE
{
    TokenPrimary = 1,
    TokenImpersonation
}

public enum SECURITY_IMPERSONATION_LEVEL
{
    SecurityAnonymous,
    SecurityIdentification,
    SecurityImpersonation,
    SecurityDelegation
}

[StructLayout(LayoutKind.Sequential)]
public struct TOKEN_STATISTICS
{
    public LUID TokenId;
    public LUID AuthenticationId;
    public UInt64 ExpirationTime;
    public TOKEN_TYPE TokenType;
    public SECURITY_IMPERSONATION_LEVEL ImpersonationLevel;
    public UInt32 DynamicCharged;
    public UInt32 DynamicAvailable;
    public UInt32 GroupCount;
    public UInt32 PrivilegeCount;
    public LUID ModifiedId;
}

[StructLayout(LayoutKind.Sequential)]
public struct LSA_STRING
{
    public LSA_STRING(ushort le, ushort ml, IntPtr buf) : this()
    {
        this.Length = le;
        this.MaximumLength = ml;
        this.Buffer = buf;
    }

    public ushort Length { get; set; }
    public ushort MaximumLength { get; set; }
    public IntPtr Buffer { get; set; }
}

[StructLayout(LayoutKind.Sequential)]
public struct SECURITY_LOGON_SESSION_DATA
{
    public UInt32 Size;
    public LUID LoginID;
    public LSA_STRING Username;
    public LSA_STRING LoginDomain;
    public LSA_STRING AuthenticationPackage;
    public UInt32 LogonType;
    public UInt32 Session;
    public IntPtr PSiD;
    public Int64 LoginTime;    // LARGE_INTEGER
    public LSA_STRING LogonServer;
    public LSA_STRING DnsDomainName;
    public LSA_STRING Upn;
    // from here = Vista+
    public UInt32 UserFlags; // 0x4000 = LOGON_OPTIMIZED, 0x8000 = LOGON_WINLOGON, 0x10000 = LOGON_PKINIT, 0x20000 = LOGON_NOT_OPTIMIZED
    public LSA_LAST_INTER_LOGON_INFO LastLogonInfo;
    public LSA_STRING LogonScript;
    public LSA_STRING ProfilePath;
    public LSA_STRING HomeDirectory;
    public LSA_STRING HomeDirectoryDrive;
    public Int64 LogoffTime;
    public Int64 KickOffTime;
    public Int64 PasswordLastSet;
    public UInt64 PasswordCanChange;
    public UInt64 PasswordMustChange;
}

[StructLayout(LayoutKind.Sequential)]
public struct LSA_LAST_INTER_LOGON_INFO
{
    UInt64 LastSuccessfulLogon; // LARGE_INTEGER
    UInt64 LastFailedLogon;     // LARGE_INTEGER
    UInt32 FailedAttemptCountSinceLastSuccessfulLogon;
}

public class WinNative
{
    [DllImport("Kernel32.dll", ExactSpelling = true)]
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    public static extern IntPtr GetCurrentProcess();

    [DllImport("Advapi32.dll", ExactSpelling = true)]
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    public static extern bool OpenProcessToken(IntPtr ProcessHandle, uint DesiredAccess, out SafeAccessTokenHandle TokenHandle);

    [DllImport("Advapi32.dll", ExactSpelling = true)]
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    public static extern bool GetTokenInformation(SafeAccessTokenHandle TokenHandle, int TokenInformationClass, IntPtr TokenInformation, int TokenInformationLength, out UInt32 ReturnLength);

    [DllImport("Secur32.dll", ExactSpelling = true)]
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    public static extern int LsaConnectUntrusted(out IntPtr LsaHandle);

    [DllImport("Secur32.dll", ExactSpelling = true)]
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    public static extern int LsaGetLogonSessionData(IntPtr luid, out IntPtr ppLogonSessionData);

    [DllImport("Secur32.dll", ExactSpelling = true)]
    [DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
    public static extern int LsaFreeReturnBuffer(IntPtr Buffer);


    public static LogonSessionData GetOwnLogonSession()
    {
        LogonSessionData result = new LogonSessionData();
        LUID? ownAuthID = null;
        IntPtr pHandle = GetCurrentProcess();
        SafeAccessTokenHandle tHandle;
        int ticStatistics = 10;
        bool res = OpenProcessToken(pHandle, (uint)System.Security.Principal.TokenAccessLevels.Query, out tHandle);
        if (res)
        {
            int bufferLength = Marshal.SizeOf(typeof(TOKEN_STATISTICS));
            IntPtr tInfoData = Marshal.AllocHGlobal(bufferLength);
            UInt32 ReturnedLength;
            res = GetTokenInformation(tHandle, ticStatistics, tInfoData, bufferLength, out ReturnedLength);
            if (res)
            {
                TOKEN_STATISTICS tStats = (TOKEN_STATISTICS)System.Runtime.InteropServices.Marshal.PtrToStructure<TOKEN_STATISTICS>(tInfoData);
                UInt32 nGroups = tStats.GroupCount;
                ownAuthID = tStats.AuthenticationId;
                System.Runtime.InteropServices.Marshal.FreeHGlobal(tInfoData);
            }
        }
        if (null != ownAuthID)
        {
                LUID trueAuthID = (LUID)ownAuthID;
                IntPtr authIDptr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(LUID)));
                Marshal.StructureToPtr<LUID>(trueAuthID, authIDptr, true);
                int lsares;
                IntPtr lsaHandle = IntPtr.Zero;
                lsares = LsaConnectUntrusted(out lsaHandle);
                if (lsares == 0)
                {
                    IntPtr sessionDataPtr;
                    lsares = LsaGetLogonSessionData(authIDptr, out sessionDataPtr);
                    if (lsares == 0)
                    {
                        SECURITY_LOGON_SESSION_DATA sessionData = (SECURITY_LOGON_SESSION_DATA)Marshal.PtrToStructure(sessionDataPtr, typeof(SECURITY_LOGON_SESSION_DATA));
                        result.LoginId = trueAuthID;
                        result.UserName = Marshal.PtrToStringUni(sessionData.Username.Buffer).Trim();
                        result.LoginDomain = Marshal.PtrToStringUni(sessionData.LoginDomain.Buffer).Trim();
                        result.Upn = Marshal.PtrToStringUni(sessionData.Upn.Buffer).Trim();
                        result.DnsDomainName = Marshal.PtrToStringUni(sessionData.DnsDomainName.Buffer).Trim();
                        result.LogonServer = Marshal.PtrToStringUni(sessionData.LogonServer.Buffer).Trim();
                        result.AuthenticationPackage = Marshal.PtrToStringUni(sessionData.AuthenticationPackage.Buffer).Trim();
                        result.LogonType = sessionData.LogonType;
                        result.UserFlags = sessionData.UserFlags;
                        result.SessionId = sessionData.Session;
                        if (sessionData.PSiD != IntPtr.Zero)
                        {
                            System.Security.Principal.SecurityIdentifier sid = new System.Security.Principal.SecurityIdentifier(sessionData.PSiD);
                            result.SID = sid.ToString();
                        }
                        LsaFreeReturnBuffer(sessionDataPtr);
                    }
                }
                
        }
        return result;
    }
}
'@
Add-Type -TypeDefinition $nativeCode
#endregion
#region get session ID
$lSess = [WinNative]::GetOwnLogonSession()
$logonID = ('0x{0:X}' -f $lSess.LoginId.LowPart)
$runningAsNetOnly = ($lSess.LogonType -eq 9)
Write-Host "Session $logonID running as /NETONLY: $runningAsNetOnly"
#endregion
#region try get user from event logs
if ($runningAsNetOnly) {
    $couldDetermineUsernameFromEventLog = $false
    $filterXml = @"
<QueryList>
    <Query Id="0" Path="Security">
        <Select Path="Security">
            *[System[EventID=4624]] and
            *[EventData[(Data[@Name='LogonType']='9') and (Data[@Name='LogonProcessName']='seclogo') and (Data[@Name='TargetLogonId']='{0}')]]
        </Select>
    </Query>
</QueryList>
"@
    $filterXml = $filterXml -f $lSess.LoginId.LowPart
    try {
        $events = @(Get-WinEvent -FilterXml $filterXml -MaxEvents 1 -EA Stop)
        Write-Verbose "Found $($events.Count) relevant events"
        if ($events.Count -gt 0) {
            $couldDetermineUsernameFromEventLog = $true
            $xmldoc = ([xml]($events[0].ToXml())).Event.EventData.Data
            $runasUser = $xmldoc.Where({$_.Name -eq 'TargetOutboundUserName'}).'#text'
            $runasDomain = $xmldoc.Where({$_.Name -eq 'TargetOutboundDomainName'}).'#text'
        } else {
            $msg = 'No events were logged in the Security log roll-over period'
        }
    } catch {
        $msg = $_.Exception.Message
    }
    if ($couldDetermineUsernameFromEventLog) {
        Write-Host "RunAs user  : $runasUser"
        Write-Host "RunAs domain: $runasDomain"
    } else {
        Write-Host "Could not determine RunAs user from event logs: $msg"
    }
}
#endregion