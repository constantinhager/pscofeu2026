runas /netonly /user:NextDoor\Sally cmd.exe
powershell -File "C:\demo\04-runas\04-01-ChekIfRunas.ps1"
powershell -File "C:\demo\04-runas\04-02-LookupRunAsUser.ps1"