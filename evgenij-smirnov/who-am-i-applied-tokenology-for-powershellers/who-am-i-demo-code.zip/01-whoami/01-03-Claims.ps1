<#
    Who am I? Applied Tokenology for PowerShellers

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Windows Identity | Claims - run as Alice!
#>
#region get whoami
$wid = [Security.Principal.WindowsIdentity]::GetCurrent()
$wid.Claims | Select-Object Issuer, Type, Value | Out-GridView
#endregion
#region claims
$wid.Claims.Where({$_.Type -like "ad:*"})
#endregion