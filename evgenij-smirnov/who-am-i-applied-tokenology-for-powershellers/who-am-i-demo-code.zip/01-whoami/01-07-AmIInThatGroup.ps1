﻿<#
    Who am I? Applied Tokenology for PowerShellers

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Am I in that group (in a multi-domain AD forest)?
#>
function Test-AmIInGroup {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$true, ParameterSetName='ByDN')]
        [string]$GroupDN,
        [Parameter(Mandatory=$true, ParameterSetName='ByNameAndDomain')]
        [string]$GroupName,
        [Parameter(Mandatory=$true, ParameterSetName='ByNameAndDomain')]
        [string]$DomainName
    )
    try {
        if ($PSCmdlet.ParameterSetName -eq 'ByDN') {
            $objectPath = ('LDAP://{0}' -f $GroupDN)
            $group = New-Object System.DirectoryServices.DirectoryEntry($objectPath)
            $group.RefreshCache()
        } else {
            $objectPath = ('LDAP://{0}/RootDSE' -f $DomainName)
            $rootDSE = New-Object System.DirectoryServices.DirectoryEntry($objectPath)
            $objectPath = ('LDAP://{0}/{1}' -f $DomainName, $rootDSE.defaultNamingContext[0])
            $groupDomain = New-Object System.DirectoryServices.DirectoryEntry($objectPath)
            $ds = New-Object System.DirectoryServices.DirectorySearcher($groupDomain)
            $ds.Filter = ('(&(objectCategory=group)(sAMAccountName={0}))' -f $GroupName)
            $group = $ds.FindOne().GetDirectoryEntry()
        }
    } catch {
        Write-Warning $_.Exception.Message
        return
    }
    $groupIsSec = ($group.GroupType[0] -band 0x80000000) -ne 0
    Write-Verbose ('Security group: {0}' -f $groupIsSec)
    if (-not $groupIsSec) {
        Write-Warning 'Token simulation only makes sense for security groups!'
        return
    }
    $groupSID = New-Object System.Security.Principal.SecurityIdentifier([byte[]]($group.objectSID[0]),0)
    $wid = [Security.Principal.WindowsIdentity]::GetCurrent()
    $userSID = $wid.User
    $userDomainSID = $userSID.AccountDomainSid
    try {
        $rootDSE = New-Object System.DirectoryServices.DirectoryEntry('LDAP://rootDSE')
        $frd = $rootDSE.rootDomainNamingContext[0]
        $dsu = New-Object System.DirectoryServices.DirectorySearcher(('GC://{0}' -f $frd))
        $dsu.Filter = ('(objectSID={0})' -f $userSID.Value)
        $null = $dsu.PropertiesToLoad.Add('distinguishedName')
        $usrRes = $dsu.FindOne()
        $userDE = $usrRes.GetDirectoryEntry()
        Write-Verbose ('User: {0}' -f $userDE.distinguishedName[0])
        $dsu.Dispose()
    } catch {
        Write-Warning ('Cannot locate user by SID: {0}' -f $_.Exception.Message)
        return
    }
    $tgs = New-Object System.DirectoryServices.DirectorySearcher($userDE)
    $tgs.SearchScope = [System.DirectoryServices.SearchScope]::Base
    $null = $tgs.PropertiesToLoad.Add('tokenGroups')
    $null = $tgs.PropertiesToLoad.Add('msds-tokenGroupNames')
    $userRes = $tgs.FindOne()
    $userTGS = $userRes.Properties['tokenGroups']
    $userTGN = $userRes.Properties['msds-tokenGroupNames']
    $tgs.Dispose()
    Write-Verbose ('The user''S tokenGroups contains {0} entries' -f $userTGS.Count)
    
    $groupIsGlobal = ($group.GroupType[0] -band 0x00000002) -ne 0
    $groupIsUni = ($group.GroupType[0] -band 0x00000008) -ne 0
    $groupIsBuiltIn = ($group.GroupType[0] -band 0x00000001) -ne 0
    $groupIsDL = ($group.GroupType[0] -band 0x00000004) -ne 0
    $amIin = $false
    if ($groupIsGlobal -or $groupIsUni) {
        Write-Verbose 'Global or Universal group, will be in tokenGroups if I am a (transitive) member'
        foreach ($tge in $userTGS) {
            $gsid = New-Object System.Security.Principal.SecurityIdentifier([byte[]]$tge,0)
            if ($gsid.Value -eq $groupSID.Value) {
                Write-Verbose ('Found: {0}' -f $groupSID.Value)
                $amIin = $true
                break
            }
        }
    } elseif ($groupIsDL) {
        Write-Verbose 'Domain local group, might contain the user or one of the tokenGroups, maybe transitively through another DL group'
        foreach ($mem in $group.member) {
            Write-Verbose ('Checking member {0}' -f $mem)
            if ($mem -eq $userDE.distinguishedName[0]) {
                Write-Verbose 'I am a direct member!'
                $amIin = $true
                break
            } elseif ($mem -in $userTGN) {
                Write-Verbose 'One of the tokenGroups is a direct member!'
                $amIin = $true
                break
            }
        }
        if (-not $amIin) {
            # doing an IN_CHAIN search as a last resort
            Write-Verbose 'No direct memberships identified'
            $dsm = New-Object System.DirectoryServices.DirectorySearcher($group)
            $dsm.SearchScope = [System.DirectoryServices.SearchScope]::Base    
            foreach ($mem in $userTGN) {
                Write-Verbose ('Checking member {0}' -f $mem)
                $dsm.Filter = ('(member:1.2.840.113556.1.4.1941:={0})' -f $mem)
                if ($dsm.FindOne().Count -gt 0) {
                    Write-Verbose ('Found a transitive member: {0}' -f $mem)
                    $amIin = $true
                    break
                }
            }
        }
    } else {
        Write-Warning 'Group is of unknown type, this should not be happening!'
        return
    }
    return $amIin
}
Test-AmIInGroup -GroupDN 'CN=ChildUG01,OU=WORK,DC=work,DC=wtf-it,DC=com' -Verbose
Test-AmIInGroup -GroupName 'ChildGG01' -DomainName 'work.wtf-it.com' -Verbose
Test-AmIInGroup -GroupName 'Domain Users' -DomainName 'wtf-it.com' -Verbose
Test-AmIInGroup -GroupDN 'CN=UserD-DLG01,OU=WORK,DC=work,DC=wtf-it,DC=com' -Verbose
Test-AmIInGroup -GroupDN 'CN=UserD-DLG04,OU=WORK,DC=work,DC=wtf-it,DC=com' -Verbose