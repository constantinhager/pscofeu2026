<#
    Who am I? Applied Tokenology for PowerShellers

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Windows (and Linux) Test for Elevation
#>
#region get whoami
$wid = [Security.Principal.WindowsIdentity]::GetCurrent()
#endregion
#region am I running elevated?
$prc = New-Object Security.Principal.WindowsPrincipal($wid)
$prc.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
#endregion
#region or the same, but simpler and (???) faster
$wid.Groups.Value.Contains('S-1-5-32-544�)
#endregion
#region run this in PS7!
[System.Environment]::IsPrivilegedProcess
#endregion