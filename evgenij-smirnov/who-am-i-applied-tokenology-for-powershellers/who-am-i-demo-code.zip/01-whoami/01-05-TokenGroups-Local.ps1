<#
    Who am I? Applied Tokenology for PowerShellers

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Windows Identity Groups in token
    Run locally as Alice on WS02 and PK01
#>
#region get whoami
$wid = [Security.Principal.WindowsIdentity]::GetCurrent()
$wid.Groups.Foreach({
    $_.Translate([System.Security.Principal.NTAccount]).Value
}) | Sort-Object
#endregion