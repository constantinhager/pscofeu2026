<#
    Who am I? Applied Tokenology for PowerShellers

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Windows Identity | Groups
#>
#region get whoami
$wid = [Security.Principal.WindowsIdentity]::GetCurrent()
#$wid.Groups
#endregion
#region resolve groups
$wid.Groups.Foreach({
    $_.Translate([System.Security.Principal.NTAccount]).Value
}) | Sort-Object
#endregion