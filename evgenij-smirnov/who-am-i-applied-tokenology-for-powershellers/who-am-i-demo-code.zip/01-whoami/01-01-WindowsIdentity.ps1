<#
    Who am I? Applied Tokenology for PowerShellers

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Windows Identity demonstration
#>
#region whoami - super simple but not very useful beyond logging
'Script starting on {0} as {1}\{2}' -f [Environment]::MachineName, [Environment]::UserDomainName, [Environment]::UserName
'Script starting on {0} as {1}\{2}' -f $env:COMPUTERNAME, $env:USERDOMAIN, $env:USERNAME
#endregion
#region whoami - real information
$wid = [Security.Principal.WindowsIdentity]::GetCurrent()
$wid | fl *
#endregion