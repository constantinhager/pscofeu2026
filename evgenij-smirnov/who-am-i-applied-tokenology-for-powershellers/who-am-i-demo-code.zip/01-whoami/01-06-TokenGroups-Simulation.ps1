﻿<#
    Who am I? Applied Tokenology for PowerShellers

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Token simulation in a multi-domain AD forest

    !!!! THIS IS JUST PROOF OF CONCEPT CODE SO
            - search result paging
            - safe referral chasing
            - and some other guardrails
         ARE NOT IMPLEMENTED!
#>
function Get-TokenGroups {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory=$false)]
        [string]$Domain
    )
    try {
        $tgtRootDSE = New-Object System.DirectoryServices.DirectoryEntry(('LDAP://{0}/rootDSE' -f $Domain))
        $tgtRootDSE.RefreshCache()
        Write-Verbose ('Target domain: {0}' -f $tgtRootDSE.defaultNamingContext[0])
    } catch {
        Write-Warning ('Error looking up target domain: {0}' -f $_.Exception.Message)
        return
    }
    try {
        $usrRootDSE = New-Object System.DirectoryServices.DirectoryEntry('LDAP://rootDSE')
        $usrRootDSE.RefreshCache()
        Write-Verbose ('User domain: {0}' -f $usrRootDSE.defaultNamingContext[0])
    } catch {
        Write-Warning ('Error looking up user domain: {0}' -f $_.Exception.Message)
        return
    }
    $wid = [Security.Principal.WindowsIdentity]::GetCurrent()
    $userSID = $wid.User
    $userDomainSID = $userSID.AccountDomainSid
    try {
        $rootDSE = New-Object System.DirectoryServices.DirectoryEntry('LDAP://rootDSE')
        $frd = $rootDSE.rootDomainNamingContext[0]
        $dsu = New-Object System.DirectoryServices.DirectorySearcher(('GC://{0}' -f $frd))
        $dsu.SearchRoot.Path = ('GC://{0}' -f $frd)
        $dsu.Filter = ('(objectSID={0})' -f $userSID.Value)
        $null = $dsu.PropertiesToLoad.Add('distinguishedName')
        $usrRes = $dsu.FindOne()
        $userDE = $usrRes.GetDirectoryEntry()
        Write-Verbose ('User: {0}' -f $userDE.distinguishedName[0])
        $dsu.Dispose()
    } catch {
        Write-Warning ('Cannot locate user by SID: {0}' -f $_.Exception.Message)
        return
    }
    try {
        $tgs = New-Object System.DirectoryServices.DirectorySearcher($userDE)
        $tgs.SearchScope = [System.DirectoryServices.SearchScope]::Base
        $null = $tgs.PropertiesToLoad.Add('tokenGroups')
        $null = $tgs.PropertiesToLoad.Add('tokenGroupsGlobalAndUniversal')
        $null = $tgs.PropertiesToLoad.Add('msds-tokenGroupNames')
        $null = $tgs.PropertiesToLoad.Add('msds-tokenGroupNamesGlobalAndUniversal')
        $userRes = $tgs.FindOne()
        $userTSG = $userRes.Properties['tokenGroups']
        $userTSU = $userRes.Properties['tokenGroupsGlobalAndUniversal']
        $userTNG = $userRes.Properties['msds-tokenGroupNames']
        $userTNU = $userRes.Properties['msds-tokenGroupNamesGlobalAndUniversal']
        $tgs.Dispose()
    } catch {
        Write-Warning ('Cannot get tokenGroups: {0}' -f $_.Exception.Message)
        return
    }
    
    $result = [PSCustomObject]@{
        'SIDs' = (New-Object System.Collections.Generic.List[System.Security.Principal.SecurityIdentifier])
        'Names' = (New-Object System.Collections.Generic.List[string])
    }
    if ($usrRootDSE.defaultNamingContext[0] -eq $tgtRootDSE.defaultNamingContext[0]) {
        Write-Verbose 'Own Domain, using tokenGroups including DL'
        $rootDSE = New-Object System.DirectoryServices.DirectoryEntry('LDAP://rootDSE')
        $frd = $rootDSE.rootDomainNamingContext[0]
        Write-Verbose ('FRD for GC search: {0}' -f $frd)
        $dsu = New-Object System.DirectoryServices.DirectorySearcher(('GC://{0}' -f $frd))
        $dsu.SearchRoot.Path = ('GC://{0}' -f $frd)
        $null = $dsu.PropertiesToLoad.Add('distinguishedName')
        foreach ($sidAD in $userTSG) { 
            $sid = New-Object System.Security.Principal.SecurityIdentifier([byte[]]$sidAD,0)
            $result.SIDs.Add($sid)
            $dsu.Filter = ('(objectSID={0})' -f $sid.Value)
            $gres = $dsu.FindOne()
            if ($null -eq $gres) {
                Write-Warning 'Could not find group by SID'
                continue
            }
            $gdn = $gres.Properties['distinguishedName'][0]
            $result.Names.Add($gdn)
        }
        $dsu.Dispose()
    } else {
        Write-Verbose 'Foreign Domain, adding DL to tokenGroups GG+UG'
        $frd = $rootDSE.rootDomainNamingContext[0]
        Write-Verbose ('FRD for GC search: {0}' -f $frd)
        $dsu = New-Object System.DirectoryServices.DirectorySearcher(('GC://{0}' -f $frd))
        $dsu.SearchRoot.Path = ('GC://{0}' -f $frd)
        $null = $dsu.PropertiesToLoad.Add('distinguishedName')
        $tgtDE = New-Object System.DirectoryServices.DirectoryEntry(('LDAP://{0}/{1}' -f $Domain, $tgtRootDSE.defaultNamingContext[0]))
        $tgtDE.RefreshCache()
        $tds = New-Object System.DirectoryServices.DirectorySearcher($tgtDE)
        $tds.SearchScope = [System.DirectoryServices.SearchScope]::Subtree
        $null = $tds.PropertiesToLoad.Add('distinguishedName')
        $null = $tds.PropertiesToLoad.Add('objectSID')
        $tds.PageSize = 1000 # a fairly safe bet but should be determined from environment, see my code from 2025
        foreach ($sidAD in $userTSU) { 
            $sid = New-Object System.Security.Principal.SecurityIdentifier([byte[]]$sidAD,0)
            $result.SIDs.Add($sid)
            $dsu.Filter = ('(objectSID={0})' -f $sid.Value)
            $gres = $dsu.FindOne()
            if ($null -eq $gres) {
                Write-Warning 'Could not find group by SID'
                continue
            }
            $gdn = $gres.Properties['distinguishedName'][0]
            $result.Names.Add($gdn)
            $tds.Filter = ('(&(objectCategory=group)(groupType:1.2.840.113556.1.4.803:=4)(member:1.2.840.113556.1.4.1941:={0}))' -f $gdn)
            $pGroups = $tds.FindAll()
            Write-Verbose ('Found {0} DL groups having {1} as member' -f $pGroups.Count, $gdn)
            foreach ($grp in $pGroups) {
                Write-Verbose ('Found {0}' -f $grp.Properties['distinguishedName'][0])
                if (-not ($result.Names.Contains($grp.Properties['distinguishedName'][0]))) {
                    $null = $result.Names.Add($grp.Properties['distinguishedName'][0])
                    $result.SIDs.Add((New-Object System.Security.Principal.SecurityIdentifier([byte[]]($grp.Properties['objectSID'][0]),0)))
                }
            }
        }
        $tds.Dispose()
        $dsu.Dispose()
    }
    Write-Verbose ('SIDs : {0}' -f $result.SIDs.Count)
    Write-Verbose ('Names: {0}' -f $result.Names.Count)
    return $result
}
$tokenInRoot = Get-TokenGroups -Domain 'wtf-it.com' -Verbose
$tokenInChild = Get-TokenGroups -Domain 'work.wtf-it.com' -Verbose