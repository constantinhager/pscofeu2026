﻿<#
    Who am I? Applied Tokenology for PowerShellers

    PSConfEU 2026 | Wiesbaden, Germany

    Evgenij Smirnov @it-pro-berlin.de
    
    Session configuration registration
#>
UnRegister-PSSessionConfiguration -Name SimpleJEA
Register-PSSessionConfiguration -Name SimpleJEA -Path (Join-Path -Path $PSScriptRoot -ChildPath '03-02-SimpleJea.pssc') -SecurityDescriptorSddl 'O:NSG:BAD:P(A;;GA;;;BA)(A;;GXGR;;;S-1-5-21-3181811696-2407034588-3348428713-1106)(A;;GXGR;;;S-1-5-21-3181811696-2407034588-3348428713-1107)(A;;GXGR;;;S-1-5-21-3181811696-2407034588-3348428713-1108)(A;;GXGR;;;S-1-5-21-3181811696-2407034588-3348428713-1109)(A;;GR;;;IU)S:P(AU;FA;GA;;;WD)(AU;SA;GXGW;;;WD)'
Restart-Service WinRM